package com.cg.entities;
import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Inventory implements Serializable{
	@Id
	@GeneratedValue
	private int inventoryId;
	private String inventoryName;
	private int quantity;
	private Double price;
	private String inventoryType;
	private Double discount;
	private Double rating;
	@ManyToOne(targetEntity=Merchant.class)
	Merchant merchant;
	
	
	public Merchant getMerchant() {
		return merchant;
	}
	public void setMerchant(Merchant merchant) {
		this.merchant = merchant;
	}
	public int getInventoryId() {
		return inventoryId;
	}
	public void setInventoryId(int inventoryId) {
		this.inventoryId = inventoryId;
	}
	public String getInventoryName() {
		return inventoryName;
	}
	public void setInventoryName(String inventoryName) {
		this.inventoryName = inventoryName;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public String getInventoryType() {
		return inventoryType;
	}
	public void setInventoryType(String inventoryType) {
		this.inventoryType = inventoryType;
	}
	public Double getDiscount() {
		return discount;
	}
	public void setDiscount(Double discount) {
		this.discount = discount;
	}
	public Double getRating() {
		return rating;
	}
	public void setRating(Double rating) {
		this.rating = rating;
	}
	public Inventory(String inventoryName, int quantity, Double price, String inventoryType,
			Double discount, Double rating) {
		super();
		this.inventoryName = inventoryName;
		this.quantity = quantity;
		this.price = price;
		this.inventoryType = inventoryType;
		this.discount = discount;
		this.rating = rating;
	}
	public Inventory() {
		super();
	}
	
	
}
