package com.cg.entities;

import java.util.Date;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;



public class ReturnItems 
{

	@Id
	@GeneratedValue
	private long returnItemId;
	private Date returndate;
	@OneToOne
	private SoldItems soldItems;
	
	
	
	
	public long getReturnItemId() {
		return returnItemId;
	}
	public void setReturnItemId(long returnItemId) {
		this.returnItemId = returnItemId;
	}
	public Date getReturndate() {
		return returndate;
	}
	public void setReturndate(Date returndate) {
		this.returndate = returndate;
	}
	public SoldItems getSoldItems() {
		return soldItems;
	}
	public void setSoldItems(SoldItems soldItems) {
		this.soldItems = soldItems;
	}

	
	public ReturnItems() {
		super();
	}
	
	
	
}
