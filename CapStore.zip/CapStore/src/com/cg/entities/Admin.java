package com.cg.entities;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class Admin implements Serializable{
	@Id
	@GeneratedValue
	private int adminId;
	private String adminName;
	private String emailId;
	private String password;
	private Double money;
	public String getAdminName() {
		return adminName;
	}
	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Double getMoney() {
		return money;
	}
	public void setMoney(Double money) {
		this.money = money;
	}
	public Admin(String adminName, String emailId, String password, Double money) {
		super();
		this.adminName = adminName;
		this.emailId = emailId;
		this.password = password;
		this.money = money;
	}
	public Admin() {
		super();
	}
	
	
	
}
