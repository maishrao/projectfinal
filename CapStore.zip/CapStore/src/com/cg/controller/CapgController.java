package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


import com.cg.entities.Customer;
import com.cg.entities.Merchant;
import com.cg.service.IDirectMerchant;

@Controller
public class CapgController {
	
	
	@Autowired
	IDirectMerchant iDirectMerchant;
	
	@RequestMapping("/index")
	public String index() {
	
		return "index";
	}
	
	/*
	@RequestMapping("/search")
	public String search(@ModelAttribute("client")Client client,Model model ) {
      client=iQueryService.search(client);
      model.addAttribute("solutionGivenBy",new String[]{"Uma","Rahul","kavita","Hema"});
		model.addAttribute(client);
		System.out.println(client);
		return "answer";
	}*/
	
	@RequestMapping("/search")
	public String search(@ModelAttribute("customer")Customer customer,Model model ) {
		

		
	return "return";
	}
	
	/* @RequestMapping(value="ret",method=RequestMethod.POST)
		public String returnmethod() {
			
		
			return "success";
		}
		*/
	
	@RequestMapping("/success")
	public String success()
	
	{
		
		return "success";
	}
}
