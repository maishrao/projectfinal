package com.cg.dao;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnItems;
import com.cg.entities.SoldItems;

public interface ICapgDAO {
	
	void plp();

	public SoldItems updateInventory(SoldItems soldItemId);
	  public Customer validatepurchase(Customer customerId);
	  public SoldItems expiry(SoldItems soldDate);

	ReturnItems generateReturnItems(SoldItems soldItems);
	
}
