package com.cg.dao;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.entities.Admin;
import com.cg.entities.Customer;
import com.cg.entities.Inventory;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnItems;
import com.cg.entities.SoldItems;

@Repository
public class CapgDAOImpl implements ICapgDAO{

	
	@PersistenceContext
	EntityManager entityManager;
	
	

	@Override
	public void plp() {
		Admin admin=new Admin("griet", "griet@gmail.com", "asdd", 20.0);
	     Customer customer=new Customer("dfjhb@gmail.com", "ddfdf", "fead", "fewre", 1540.45);
	     Merchant merchant=new Merchant("afefq", "qer", "eefewf", "efqf", 1.00, 200.0);
	     Inventory inventory=new Inventory("qqede", 50, 200.00, "edeq", 0.00, 0.00);
	     inventory.setMerchant(merchant);
	     //customer.setCart(inventory);
	     //customer.setWishList(inventory);
	     entityManager.persist(admin);
	     entityManager.persist(merchant);
	     entityManager.persist(inventory);
	     entityManager.persist(customer);
	     entityManager.flush();
		
	}



	@Override
	public SoldItems updateInventory(SoldItems soldItems) {
		
		
		
		soldItems.getInventory().getQuantity();
		
		
		return null;
	}



	@Override
	public Customer validatepurchase(Customer customerId) {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public SoldItems expiry(SoldItems soldDate) {
	//	long noOfDaysBetween = DAYS.between(soldDate, LocalDate);
		return null;
	}



	@Override
	public ReturnItems generateReturnItems(SoldItems soldItems) {
		// TODO Auto-generated method stub
		return null;
	}



	
	
}
