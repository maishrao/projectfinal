package com.cg.service;

import java.util.List;

import com.cg.entities.Customer;
import com.cg.entities.Merchant;
import com.cg.entities.ReturnItems;
import com.cg.entities.SoldItems;


public interface IDirectMerchant 
{


	public SoldItems updateInventory(SoldItems soldItems);
    public Customer validatepurchase(Customer customerId);
	public SoldItems expiry(SoldItems soldDate );
	public abstract ReturnItems generateReturnItems(SoldItems soldItems);
	
}
