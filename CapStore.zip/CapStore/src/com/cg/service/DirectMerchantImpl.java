package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.dao.ICapgDAO;
import com.cg.entities.Customer;
import com.cg.entities.ReturnItems;
import com.cg.entities.SoldItems;


public class DirectMerchantImpl implements IDirectMerchant {

	
	@Autowired
	ICapgDAO iCapgDao;

	@Override
	public SoldItems updateInventory(SoldItems soldItems) {
		
		return iCapgDao.updateInventory(soldItems);
	}

	@Override
	public Customer validatepurchase(Customer customerId) {
		// TODO Auto-generated method stub
		return iCapgDao.validatepurchase(customerId);
	}

	@Override
	public SoldItems expiry(SoldItems soldDate) {
		// TODO Auto-generated method stub
		return iCapgDao.updateInventory(soldDate);
	}

	@Override
	public ReturnItems generateReturnItems(SoldItems soldItems) {
		// TODO Auto-generated method stub
		return iCapgDao.generateReturnItems(soldItems);
	}


		
	}


