package com.cg.service;

public interface ThirdPartyMerchant 
{

	
}
